import os
import shutil
from os import linesep
from pathlib import Path


## Get html output of all raw .py notebooks
def test_all_notebooks():
    """
    Test that all notebooks included in ./scenarios create the
    expected output as shown in ./expected
    """

    this_dir = Path(__file__).parent

    created_dir = Path(this_dir / "created")
    if created_dir.exists():
        shutil.rmtree(created_dir)
    created_dir.mkdir()

    scenario_dir = Path(this_dir / "scenarios")
    expected_dir = Path(this_dir / "html_scenario_fixtures")

    for path_to_notebook in scenario_dir.glob("./*.ipynb"):

        os.system(
            f"jupyter-nbconvert --to html --output-dir='{created_dir.resolve()}' --ExecutePreprocessor.timeout=None --execute '{path_to_notebook}'"
        )

        # Get the name of the html output we've just created
        html_name = str(path_to_notebook.name).replace(".ipynb", ".html")
        new_output = list(created_dir.glob(f"./{html_name}"))[0]

        # Check that there's an expected version of it (a fixture in dev speak)
        # If not give some information as to whats gone wrong, as forgetting to
        # create a fixture is pretty guaranteed to happen.
        old_output_file_glob_list = list(expected_dir.glob(f"./{html_name}"))
        all_old_output_files = list(expected_dir.glob(f"./*.html"))
        old_files_as_line_delmited_list = "\n".join([str(x) for x in all_old_output_files])
        assert len(old_output_file_glob_list) == 1, (f'''
            We expected but did not find file "{html_name}" in the
            <your local path>/scenarios/expected directory.
            
            The files we have are:

{old_files_as_line_delmited_list}

            There should be:
            - a html file of <your local path>/scenarios/expected/{html_name}
            - it should be the html of what <your local path>/scenarios/{path_to_notebook.name}
              should look like once ran.

            note - run your notebook then use Jupyters export to html functionality
            to create.

            ''')
        old_output = old_output_file_glob_list[0]

        with open(new_output) as f1:
            with open(old_output) as f2:
                assert f1.read() == f2.read(), (
                    f"Unexpected output:{linesep}"
                    f"- the new output : {new_output.resolve()}{linesep}"
                    f"- created from   : {path_to_notebook.resolve()}{linesep}"
                    f"- does not match : {old_output.resolve()}{linesep}"
                )
